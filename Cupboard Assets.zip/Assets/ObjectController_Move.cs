using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectController_Move : MonoBehaviour
{
    [Header("�ƶ�����")]
    public float distance = 0.5f;
    [Header("����")]
    public bool reversal = false;
    [Header("�ƶ��ٶ�")]
    public float moveSpeed = 1;
    [Header("�ƶ�����")]
    public bool xDirection, yDirection, zDirection;
    [Header("����ѭ��")]
    public bool isLoop = false;
    Vector3 Direction = Vector3.zero;
    Vector3 StartPos = Vector3.zero;
    /// <summary>
    /// ��ǰ��״̬
    /// </summary>
    [HideInInspector]
    public bool state = false;
    /// <summary>
    /// �Ƿ�ɲ���
    /// </summary>
    [HideInInspector]
    public bool ActivateControl = true;
    protected void Start()
    {
        StartPos = transform.position;
        int i = 1;
        if (reversal)
            i = -1;
        if (xDirection)
            Direction = transform.right* distance;
        if (yDirection)
            Direction = transform.up * distance;
        if (zDirection)
            Direction = transform.forward * distance;
        Direction *= i;
        Direction += transform.position;
    }
    public bool test = false;
    private void Update()
    {
        if (test)
        {
            Control();
            test = false;
        }
    }
    bool Move = false;
    public void Control()
    {
        if (IsControl())
        {
            Move = true;
            ActivateControl = false;
        }
    }
    public bool IsControl()
    {
        if (ActivateControl)
        {
            return true;
        }
        return false;
    }
    private void LateUpdate()
    {
        if (Move)
        {
            if (state)
            {
                if (StartMove(StartPos))
                {
                    state = false;
                }
            }
            else
            {
                if (StartMove(Direction))
                {
                    state = true;
                    if (isLoop)
                        Move = true;
                }
            }

        }
    }
    bool StartMove(Vector3 EndPos)
    {
        transform.position = Vector3.Lerp(transform.position, EndPos, moveSpeed * Time.deltaTime);
        if (Vector3.Distance(transform.position, EndPos) < 0.05f)
        {
            transform.position = EndPos;
            Move = false;
            ActivateControl = true;
            return true;
        }
        return false;
    }
}
