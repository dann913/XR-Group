using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Item : MonoBehaviour
{
    public AudioSource ab;
    public static bool isDown = false;

    private void Awake()
    {
        ab = GetComponent<AudioSource>();
    }
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private void OnMouseDown()
    {
        if (isDown) return;
        Invoke("S", 0.5f);
        isDown = true;
        ab.Play();
        GetComponent<Animator>().SetTrigger("T");
    }
    private void S()
    {
        isDown = false;
    }
}
