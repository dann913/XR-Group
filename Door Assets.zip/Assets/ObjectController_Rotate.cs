using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class ObjectController_Rotate : MonoBehaviour
{
    [Header("�Ű���")]
    public ObjectController_Rotate objectController_Door;
    [Header("��ת�Ƕ�")]
    public float angle = 90f;
    [Header("����")]
    public bool reversal = false;
    [Header("��ת�ٶ�")]
    public float openSpeed = 100;
    [Header("��ת����")]
    public bool xAxial, yAxial, zAxial;

    float menAngle = 0;
    public Action PlayAction;
    public Action EndAction = null;

    [HideInInspector]
    public bool state = false;

    /// <summary>
    /// �Ƿ�ɲ���
    /// </summary>
    [HideInInspector]
    public bool ActivateControl = true;
    Vector3 angleStart = Vector3.zero;
    Vector3 angleEnd = Vector3.zero;
    protected void Start()
    {
        angleStart = transform.eulerAngles;
        Vector3 vector = Vector3.zero;
        if (xAxial)
            vector.x = angle;
        if (yAxial)
            vector.y = angle;
        if (zAxial)
            vector.z = angle;
        angleEnd = transform.eulerAngles + vector;
    }
    public bool test = false;
    private void Update()
    {
        if (test)
        {
            Control();
            test = false;
        }
    }
    public void Control()
    {
        if (IsControl())
        {
            if (objectController_Door)
            {
                if (objectController_Door.state == false)
                {
                    objectController_Door.PlayAction = PlayOpenDoor;
                    objectController_Door.Control();
                    ActivateControl = false;
                }
                else
                {
                    objectController_Door.PlayAction = null;
                    PlayOpenDoor();
                }
            }
            else
            {
                PlayOpenDoor();
            }
        }
    }
    void ActivateDoor()
    {
        ActivateControl = true;
        if (EndAction != null)
            EndAction();
    }

    public bool IsControl()
    {
        if (ActivateControl == false)
            return false;
        return true;
    }
    void PlayOpenDoor()
    {
        Open = true;
    }
    bool open = false;
    public bool Open
    {
        get => open;
        set
        {
            if (value)
            {
                ActivateControl = false;
            }
            else
            {
                ActivateControl = true; ;
            }
            open = value;
        }
    }
    private void LateUpdate()
    {
        if (Open == true)
        {
            int i = 1;
            if (reversal)
                i = -1;
            Vector3 vector = Vector3.zero;
            if (xAxial)
                vector.x = openSpeed * Time.deltaTime;
            if (yAxial)
                vector.y = openSpeed * Time.deltaTime;
            if (zAxial)
                vector.z = openSpeed * Time.deltaTime;
            if (state == false)
            {
                transform.Rotate(vector * i);
            }
            else
            {
                transform.Rotate(vector * -1 * i);
            }

            menAngle += openSpeed * Time.deltaTime;
            if (menAngle > angle)
            {

                if (state == false)
                {
                    if (reversal)
                    {
                        vector = Vector3.zero;
                        if (xAxial)
                            vector.x = angle;
                        if (yAxial)
                            vector.y = angle;
                        if (zAxial)
                            vector.z = angle;
                        transform.eulerAngles = angleEnd - vector * 2;
                    }
                    else
                        transform.eulerAngles = angleEnd;
                    state = true;
                    Open = false;
                }
                else
                {
                    transform.eulerAngles = angleStart;
                    state = false;
                    Open = false;
                    if (objectController_Door)
                    {
                        if (objectController_Door.state)
                        {
                            objectController_Door.Control();
                            ActivateControl = false;
                            if (objectController_Door.EndAction == null)
                                objectController_Door.EndAction = ActivateDoor;
                        }
                    }
                    else
                    {
                        ActivateDoor();
                    }
                }
                menAngle = 0;
                OnPutCallBack();
            }
        }
    }
    public void OnPutCallBack()
    {
        if (PlayAction != null)
            PlayAction();
    }
}
